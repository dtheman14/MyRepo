﻿using BikeShop.Contracts;
using BikeShop.Models;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.Repository
{
    public class BikeRepository: BaseRepository, IBikeRepository
    {
        public IEnumerable<Bike> GetAll(bool returnAvailableOnly=true)
        {
            var connection = OpenConnection();
            try
            {
                var result = connection.Query<Bike>("[dbo].[BikeGetAll]", null, commandType: System.Data.CommandType.StoredProcedure);
                if (result.Any())
                {
                    var inUsedBikes = new List<int>();
                    if (returnAvailableOnly)
                    {
                        var availableBikes = connection.Query<Transaction>("[dbo].[BikeGetAllAvailable]", null, commandType: System.Data.CommandType.StoredProcedure);
                        foreach(var itm in availableBikes)
                        {
                            if(itm.CheckIn == null)
                            {
                                inUsedBikes.Add(itm.BikeID);
                            }
                        }

                        if(inUsedBikes.Any())
                        {
                            var validList = new List<Bike>();

                            foreach(var itm in result)
                            {
                                if (inUsedBikes.Contains(itm.BikeID))
                                {
                                    continue;
                                }
                                else
                                    validList.Add(itm);
                            }

                            return validList;
                        }

                    }

                    return result.ToList();
                }
                else
                    return new List<Bike>();

            }
            catch (Exception ex)
            {
                //CAN LOG THE ERROR HERE
                return null;
            }
            finally
            {
                connection.Close();
            }
        }

    }
}
