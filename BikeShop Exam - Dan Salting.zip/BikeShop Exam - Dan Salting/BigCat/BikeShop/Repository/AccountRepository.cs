﻿using BikeShop.Contracts;
using BikeShop.Models;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BikeShop.Repository
{
    public class AccountRepository: BaseRepository, IAccountRepository
    {
        public Account GetUser(string username, string password)
        {
            var param = new DynamicParameters();
            param.Add("@Username", username);
            param.Add("@Password", password);

            var connection = OpenConnection();
            try
            {
                var result = connection.Query<Account>("[dbo].[AccountGetUser]", param, commandType: System.Data.CommandType.StoredProcedure);

                if (result.Any())
                    return result.First();
                else
                    return null;
            }
            catch (Exception ex)
            {
                //CAN LOG THE ERROR HERE
                return null;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
