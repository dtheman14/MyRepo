﻿using BikeShop.Contracts;
using BikeShop.Models;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
namespace BikeShop.Repository
{
    public class TransactionRepository: BaseRepository, ITransactionRepository
    {
        public void InsertUpdate(Transaction model)
        {
            var param = new DynamicParameters();
            param.Add("@TransactionID", model.TransactionID);
            param.Add("@BikeID", model.BikeID);
            param.Add("@CustomerName", model.CustomerName);
            param.Add("@CheckOut", model.CheckOut);

            if (model.CheckIn != null)
                param.Add("@CheckIn", model.CheckIn);

            var connection = OpenConnection();
            try
            {
                connection.Execute("[dbo].[TransactionInsertUpdate]", param, commandType: System.Data.CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {
                //CAN LOG THE ERROR HERE
            }
            finally
            {
                connection.Close();
            }
        }

        IEnumerable<Transaction> ITransactionRepository.GetAll()
        {
            var connection = OpenConnection();
            try
            {
                var result = connection.Query<Transaction>("[dbo].[TransactionGetAll]", null, commandType: System.Data.CommandType.StoredProcedure);

                if (result.Any())
                    return result.ToList();
                else
                    return new List<Transaction>();
            }
            catch (Exception ex)
            {
                //CAN LOG THE ERROR HERE
                return null;
            }
            finally
            {
                connection.Close();
            }
        }

        Transaction ITransactionRepository.GetById(int id)
        {
            var param = new DynamicParameters();
            param.Add("@TransactionID", id);

            var connection = OpenConnection();
            try
            {
                var result = connection.Query<Transaction>("[dbo].[TransactionGetById]", param, commandType: System.Data.CommandType.StoredProcedure);

                if (result.Any())
                    return result.First();
                else
                    return new Transaction();
            }
            catch (Exception ex)
            {
                //CAN LOG THE ERROR HERE
                return null;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
