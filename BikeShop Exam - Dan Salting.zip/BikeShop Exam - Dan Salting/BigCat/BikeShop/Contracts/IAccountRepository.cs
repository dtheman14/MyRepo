﻿using BikeShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.Contracts
{
    public interface IAccountRepository
    {
        Account GetUser(string username, string password);
    }
}
