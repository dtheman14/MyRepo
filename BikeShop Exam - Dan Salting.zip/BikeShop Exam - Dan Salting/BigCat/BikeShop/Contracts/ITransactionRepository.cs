﻿using BikeShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.Contracts
{
    public interface ITransactionRepository
    {
        void InsertUpdate(Transaction model);
        IEnumerable<Transaction> GetAll();
        Transaction GetById(int id);
    }
}
