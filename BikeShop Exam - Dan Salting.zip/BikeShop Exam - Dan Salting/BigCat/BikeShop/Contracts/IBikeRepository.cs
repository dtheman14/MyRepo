﻿using BikeShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.Contracts
{
    public interface IBikeRepository
    {
        IEnumerable<Bike> GetAll(bool returnAvailableOnly = true);
    }
}
