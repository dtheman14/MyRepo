﻿
using BikeShop.Contracts;
using BikeShop.Models;
using BikeShop.Repository;
using BikeShop.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.Controllers
{
    public class TransactionController : Controller
    {
        private readonly ITransactionRepository _transactionRepository;
        private readonly IBikeRepository _bikeRepository;
        public TransactionController(ITransactionRepository transactionRepository, IBikeRepository bikeRepository)
        {
            _transactionRepository = transactionRepository;
            _bikeRepository = bikeRepository;
        }


        // GET: TransactionController
        [Authorize(Roles = "Admin, Staff")]
        public ActionResult Index()
        {
            var view = new List<ListViewModel>();
            var list = _transactionRepository.GetAll();

            foreach (var itm in list)
            {
                view.Add(new ListViewModel()
                {
                    TransactionID = itm.TransactionID,
                    BikeName = itm.BikeName,
                    CustomerName = itm.CustomerName,
                    CheckIn = itm.CheckIn,
                    CheckOut = itm.CheckOut,
                    DateModified = itm.DateModified
                });
            }

            view = view.OrderByDescending(q => q.DateModifiedStr).ToList();

            return View(view);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Manage()
        {
            return View();
        }


        // GET: TransactionController/Create
        [Authorize(Roles = "Admin, Staff")]
        public ActionResult Create()
        {
            var view = new AddEditViewModel()
            {
                Bikes = _bikeRepository.GetAll().ToList(),
                CheckOut = DateTime.Now
            };

            return View(view);
        }

        // POST: TransactionController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, Staff")]
        public ActionResult Create(AddEditViewModel model)
        {

            try
            {
                var rental = new Transaction()
                {
                    BikeID = model.BikeID,
                    CustomerName = model.CustomerName,
                    CheckOut = model.CheckOut
                };

                _transactionRepository.InsertUpdate(rental);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: TransactionController/Edit/5
        [Authorize(Roles = "Admin, Staff")]
        public ActionResult Edit(int id)
        {
            var itm = _transactionRepository.GetById(id);

            var view = new AddEditViewModel()
            {
                TransactionID = itm.TransactionID,
                BikeID = itm.BikeID,
                BikeName = itm.BikeName,
                CustomerName = itm.CustomerName,
                CheckOut = itm.CheckOut,
                CheckIn = itm.CheckIn ?? DateTime.Now
            };
            return View(view);
        }

        // POST: TransactionController/Update
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, Staff")]
        public ActionResult Update(AddEditViewModel model)
        {
            try
            {
                var rental = new Transaction()
                {
                    TransactionID = model.TransactionID,
                    BikeID = model.BikeID,
                    CustomerName = model.CustomerName,
                    CheckOut = model.CheckOut,
                    CheckIn = model.CheckIn
                };

                _transactionRepository.InsertUpdate(rental);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
       
    }
}
