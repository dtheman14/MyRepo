﻿using BikeShop.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using BikeShop.Contracts;
using BikeShop.ViewModels.Account;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using BikeShop.Models;

namespace BikeShop.Controllers
{
    public class AccountController : Controller
    {
        private readonly DbContext _context;
        private readonly IAccountRepository _accountRepository;
        public AccountController(DbContext context, IAccountRepository accountRepository)
        {
            _context = context;
            _accountRepository = accountRepository;
        }


        //*****DEMONSTRATE RETRIEVING OF DATA FROM DATABASE USING ENTITY FRAMEWORK (DB FIRST)****
        // GET: AccountController
        [Authorize(Roles = "Admin")]
        public ActionResult Index()
        {

            var list = _context.Account.ToList();

            var view = new List<AccountListViewModel>();

            foreach(var itm in list)
            {
                view.Add(new AccountListViewModel()
                {
                    AccountID = itm.AccountID,
                    FirstName = itm.FirstName,
                    LastName = itm.LastName,
                    RoleID = itm.RoleID,
                    RoleName = itm.RoleName,
                    Username = itm.Username,
                    IsActive = itm.IsActive
                });
            }

            return View(view);
        }

        public ActionResult AccessDenied()
        {
            return View();
        }

        public ActionResult Create()
        {
            var view = new AccountAddEditViewModel()
            {
                Roles = Entity.GetRoles()
            };

            ModelState.Clear();
            return View(view);
        }

        [HttpPost]
        public ActionResult Create(AccountAddEditViewModel model)
        {
            var account = new Account();
            account = _context.Account.Where(q => q.Username.ToLower() == model.Username.ToLower()).FirstOrDefault();
            if(account != null)
            {
                ViewBag.UserExistEror = "Username already exist.";

                var view = new AccountAddEditViewModel()
                {
                    Roles = Entity.GetRoles()
                };
                return View(view);
            }
            ViewBag.UserExistEror = string.Empty;

            account = new Account()
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                RoleID = model.RoleID,
                Username = model.Username,
                Password = model.Password,
                IsActive = model.IsActive
            };

            _context.Attach(account);
            _context.Entry(account).State = EntityState.Added;
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            var account = _context.Account.First(q => q.AccountID == id);

            var view = new AccountAddEditViewModel()
            {
                AccountID = id,
                FirstName = account.FirstName,
                LastName = account.LastName,
                RoleID = account.RoleID,
                RoleName = account.RoleName,
                Username = account.Username,
                Password = account.Password,
                IsActive = account.IsActive
            };

            return View(view);
        }


        [Authorize(Roles = "Admin")]
        [HttpPost]
        public ActionResult Update (AccountAddEditViewModel model)
        {
            var account = _context.Account.First(q => q.AccountID == model.AccountID);
            account.FirstName = model.FirstName;
            account.LastName = model.LastName;
            account.Password = model.Password;
            account.IsActive = model.IsActive;

            _context.Attach(account);
            _context.Entry(account).State = EntityState.Modified;
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        public ActionResult Login()
        {
            return View();
        }


        //*****DEMONSTRATE RETRIEVING OF DATA FROM THE DATABASE VIA STORED PROCEDURE USING DAPPER***
        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            if(string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return RedirectToAction("Login");
            }


            ClaimsIdentity identity = null;
            bool isAuthenticated = false;

            var user = _accountRepository.GetUser(username, password);

            if(user != null)
            {
                if(!user.IsActive)
                    return View();

                identity = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, username),
                    new Claim(ClaimTypes.Role, user.RoleName)
                }, CookieAuthenticationDefaults.AuthenticationScheme);
                isAuthenticated = true;
            }

            if(isAuthenticated)
            {
                var principal = new ClaimsPrincipal(identity);
                var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                return RedirectToAction("Index", "Transaction");
            }

            return View();
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Transaction");
        }

    }
}
