﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.ViewModels
{
    public class ListViewModel
    {
        public int TransactionID { get; set; }
        public int BikeID { get; set; }

        [Display(Name = "Bike Name")]
        public string BikeName { get; set; }

        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }

        [Display(Name = "Check Out")]
        public DateTime CheckOut { get; set; }

        [Display(Name = "Check In")]
        public DateTime? CheckIn { get; set; }

        [Display(Name = "Total Time Spent")]
        public string TotalTimeSpent
        {
            get
            {
                if (CheckIn == null) 
                    return string.Empty;

                var timespan = Convert.ToDateTime(CheckIn).Subtract(CheckOut) ;

                return string.Format("{0}Hr {1}Min {2}Sec", timespan.Hours, timespan.Minutes, timespan.Seconds);
            }
        }

        [Display(Name = "Date Modified")]
        public DateTime DateModified { get; set; }

        public string DateModifiedStr
        {
            get
            {
                return this.DateModified.ToString("dd/MM/yyyy hh:mm:ss tt");
            }
        }
    }
}
