﻿using BikeShop.Models;
using BikeShop.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.ViewModels
{
    public class AddEditViewModel
    {
        public int TransactionID { get; set; }

        [Required]
        [Display(Name = "Bike ID")]
        public int BikeID { get; set; }

        [Display(Name = "Bike Name")]
        public string BikeName { get; set; }


        [Required]
        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }


        [Display(Name = "Check Out")]
        public DateTime CheckOut { get; set; }


        [Display(Name = "Check In")]
        public DateTime? CheckIn { get; set; }

        public List<Bike> Bikes { get; set; }

    }
}
