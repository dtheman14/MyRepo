﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.Models
{
    public class Entity
    {
        public enum Roles
        {
            Admin = 1,
            Staff = 2
        }

        public static string GetRoleName(int role)
        {
            return Enum.GetName(typeof(Roles), role);
        }

        public static List<Role> GetRoles()
        {
            var list = new List<Role>();

            list.Add(new Role
            {
                RoleID = (int)Roles.Admin,
                RoleName = GetRoleName((int)Roles.Admin)
            });

            list.Add(new Role
            {
                RoleID = (int)Roles.Staff,
                RoleName = GetRoleName((int)Roles.Staff)
            });

            return list;
        }
    }
}
