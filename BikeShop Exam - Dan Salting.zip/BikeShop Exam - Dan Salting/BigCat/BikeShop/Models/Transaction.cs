﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.Models
{
    public class Transaction
    {
        public int TransactionID { get; set; }
        public int BikeID { get; set; }
        public string BikeName { get; set; }
        public string CustomerName { get; set; }
        public DateTime CheckOut { get; set; }
        public DateTime? CheckIn { get; set; }
        public DateTime DateModified { get; set; }
    }
}
