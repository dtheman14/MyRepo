﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.Models
{
    public class Bike
    {
        public int BikeID { get; set; }
        public string BikeName { get; set; }
        public string Description { get; set; }

    }
}
