﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeShop.Models
{
    public class Role
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }
    }
}
